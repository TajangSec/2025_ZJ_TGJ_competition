<?php
header("content-type:text/html;charset=utf-8");
include("lib/manager.php");

// 配置项
define('AUTH_USER', 'admin');
define('AUTH_PASS', 'admin@123');
define('SESSION_COOKIE', 'portal_session');

$userInput = isset($_POST['user']) ? $_POST['user'] : die('Access denied: username required');
$passInput = isset($_POST['pass']) ? $_POST['pass'] : die('Access denied: password required');

if($userInput === AUTH_USER && $passInput === AUTH_PASS) {
    echo '<script>alert("Authentication successful!")</script>';
    echo "<h2>Industrial Control Portal</h2>";
    echo "<p>Authenticated as: " . htmlspecialchars($userInput) . "</p>";

    if(!isset($_COOKIE[SESSION_COOKIE])) {
        $sessionObj = new PortalUser(AUTH_USER);
        $encodedData = base64_encode(serialize($sessionObj));
        setcookie(SESSION_COOKIE, $encodedData, time()+3600, "/", "", false, true);
        echo "<p>Session initialized</p>";
    } else {
        $serializedData = base64_decode($_COOKIE[SESSION_COOKIE]);
        unserialize($serializedData);
    }

    echo '<div class="dashboard">
            <h3>Device Monitoring</h3>
            <p>Connected devices: 15</p>
            <p>Firmware version: v3.1.2</p>
          </div>';
} else {
    echo "<script>alert('Invalid credentials!');window.location.href='./index.html';</script>";
}
?>