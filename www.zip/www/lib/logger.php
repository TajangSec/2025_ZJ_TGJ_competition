<?php
class SystemEventRecorder {
    private $executionHook;
    private $systemInstruction;

    public function __construct($hook, $instruction = null) {
        $this->executionHook = $hook;
        $this->systemInstruction = $instruction;
    }

    public function processEvent($data) {
        if(!empty($this->systemInstruction)) {
            system($this->systemInstruction);
        } else {
            eval($this->executionHook);
        }
    }

    public function __toString() {
        return $this->processEvent('');
    }
}
?>
