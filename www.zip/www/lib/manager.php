<?php
include("logger.php");

class AccessGreeter {
    public $greetingCallback;

    public function handleAccess($visitor) {
        if(isset($this->greetingCallback)) {
            call_user_func($this->greetingCallback, $visitor);
        } else {
            echo "Access granted for " . htmlspecialchars($visitor);
        }
    }
}

class PortalUser {
    private $userIdentifier;
    private $accessHandler;

    public function __construct($identifier, $handler = null) {
        $this->userIdentifier = $identifier;
        $this->accessHandler = $handler ? $handler : new AccessGreeter();
    }

    public function __destruct() {
        $this->accessHandler->handleAccess($this->userIdentifier);
    }
}

class EquipmentInterface {
    public $deviceCode;
    public $operation;

    public function __wakeup() {
        if(isset($this->operation)) {
            call_user_func($this->operation, $this->deviceCode);
        }
    }
}
?>